/*
 * File: autosar_tpc_actuator_private.h
 *
 * Code generated for Simulink model 'autosar_tpc_actuator'.
 *
 * Model version                  : 1.39
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Thu Aug  3 09:12:53 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_autosar_tpc_actuator_private_h_
#define RTW_HEADER_autosar_tpc_actuator_private_h_
#include "rtwtypes.h"

extern uint32 plook_u32f_linckan(float32 u, const float32 bp[], uint32 maxIndex);
extern uint32 linsearch_u32f(float32 u, const float32 bp[], uint32 startIndex);

#endif                          /* RTW_HEADER_autosar_tpc_actuator_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
