/*
 * File: autosar_tpc_pedal_sensor_private.h
 *
 * Code generated for Simulink model 'autosar_tpc_pedal_sensor'.
 *
 * Model version                  : 1.45
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Thu Aug  3 09:14:23 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_autosar_tpc_pedal_sensor_private_h_
#define RTW_HEADER_autosar_tpc_pedal_sensor_private_h_
#include "rtwtypes.h"

extern float32 look1_iu16bflftf_linlcpw(uint16 u0, const float32 bp0[], const
  float32 table[], uint32 maxIndex);

#endif                      /* RTW_HEADER_autosar_tpc_pedal_sensor_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
