/*
 * File: autosar_tpc_controller_private.h
 *
 * Code generated for Simulink model 'autosar_tpc_controller'.
 *
 * Model version                  : 1.44
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Thu Aug  3 09:13:38 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_autosar_tpc_controller_private_h_
#define RTW_HEADER_autosar_tpc_controller_private_h_
#include "rtwtypes.h"
#endif                        /* RTW_HEADER_autosar_tpc_controller_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
