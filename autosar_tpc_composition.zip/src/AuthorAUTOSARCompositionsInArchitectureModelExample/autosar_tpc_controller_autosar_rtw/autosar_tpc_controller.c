/*
 * File: autosar_tpc_controller.c
 *
 * Code generated for Simulink model 'autosar_tpc_controller'.
 *
 * Model version                  : 1.44
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Thu Aug  3 09:13:38 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "autosar_tpc_controller.h"
#include "autosar_tpc_controller_private.h"

/* Block states (default storage) */
DW_autosar_tpc_controller_T autosar_tpc_controller_DW;

/* Model step function */
void Controller_Step(void)
{
  float32 rtb_IntegralGain;
  float32 rtb_Sum;
  float32 rtb_SignPreIntegrator;
  boolean rtb_NotEqual;
  float32 rtb_IntegralGain_0;

  /* Sum: '<Root>/Subtract' incorporates:
   *  Inport: '<Root>/APP_Percent_Value'
   *  Inport: '<Root>/TPS_Percent_Value'
   */
  rtb_IntegralGain = Rte_IRead_Controller_Step_APP_Percent_Value() -
    Rte_IRead_Controller_Step_TPS_Percent_Value();

  /* Sum: '<S44>/Sum' incorporates:
   *  Delay: '<S28>/UD'
   *  DiscreteIntegrator: '<S35>/Integrator'
   *  Sum: '<S28>/Diff'
   */
  rtb_Sum = (rtb_IntegralGain + autosar_tpc_controller_DW.Integrator_DSTATE) +
    (0.0F - autosar_tpc_controller_DW.UD_DSTATE);

  /* DeadZone: '<S26>/DeadZone' */
  if (rtb_Sum > 100.0F) {
    rtb_SignPreIntegrator = rtb_Sum - 100.0F;
  } else if (rtb_Sum >= -100.0F) {
    rtb_SignPreIntegrator = 0.0F;
  } else {
    rtb_SignPreIntegrator = rtb_Sum - -100.0F;
  }

  /* End of DeadZone: '<S26>/DeadZone' */

  /* RelationalOperator: '<S26>/NotEqual' incorporates:
   *  Gain: '<S26>/ZeroGain'
   */
  rtb_NotEqual = (0.0F != rtb_SignPreIntegrator);

  /* Signum: '<S26>/SignPreSat' */
  if (rtb_SignPreIntegrator < 0.0F) {
    rtb_SignPreIntegrator = -1.0F;
  } else {
    if (rtb_SignPreIntegrator > 0.0F) {
      rtb_SignPreIntegrator = 1.0F;
    }
  }

  /* End of Signum: '<S26>/SignPreSat' */

  /* Gain: '<S32>/Integral Gain' */
  rtb_IntegralGain *= 2.0F;

  /* DataTypeConversion: '<S26>/DataTypeConv1' */
  rtb_SignPreIntegrator = fmodf(rtb_SignPreIntegrator, 256.0F);

  /* Signum: '<S26>/SignPreIntegrator' */
  if (rtb_IntegralGain < 0.0F) {
    rtb_IntegralGain_0 = -1.0F;
  } else if (rtb_IntegralGain > 0.0F) {
    rtb_IntegralGain_0 = 1.0F;
  } else {
    rtb_IntegralGain_0 = rtb_IntegralGain;
  }

  /* End of Signum: '<S26>/SignPreIntegrator' */

  /* DataTypeConversion: '<S26>/DataTypeConv2' */
  rtb_IntegralGain_0 = fmodf(rtb_IntegralGain_0, 256.0F);

  /* Switch: '<S26>/Switch' incorporates:
   *  Constant: '<S26>/Constant1'
   *  DataTypeConversion: '<S26>/DataTypeConv1'
   *  DataTypeConversion: '<S26>/DataTypeConv2'
   *  Logic: '<S26>/AND3'
   *  RelationalOperator: '<S26>/Equal1'
   */
  if (rtb_NotEqual && ((rtb_SignPreIntegrator < 0.0F ? (sint32)(sint8)-(sint8)
                        (uint8)-rtb_SignPreIntegrator : (sint32)(sint8)(uint8)
                        rtb_SignPreIntegrator) == (rtb_IntegralGain_0 < 0.0F ?
        (sint32)(sint8)-(sint8)(uint8)-rtb_IntegralGain_0 : (sint32)(sint8)
        (uint8)rtb_IntegralGain_0))) {
    rtb_IntegralGain = 0.0F;
  }

  /* End of Switch: '<S26>/Switch' */

  /* Update for DiscreteIntegrator: '<S35>/Integrator' */
  autosar_tpc_controller_DW.Integrator_DSTATE += 0.005F * rtb_IntegralGain;

  /* Update for Delay: '<S28>/UD' */
  autosar_tpc_controller_DW.UD_DSTATE = 0.0F;

  /* Saturate: '<S42>/Saturation' */
  if (rtb_Sum > 100.0F) {
    rtb_Sum = 100.0F;
  } else {
    if (rtb_Sum < -100.0F) {
      rtb_Sum = -100.0F;
    }
  }

  /* End of Saturate: '<S42>/Saturation' */

  /* Outport: '<Root>/ThrCmd_Percent_Value' */
  Rte_IWrite_Controller_Step_ThrCmd_Percent_Value(rtb_Sum);
}

/* Model initialize function */
void Controller_Init(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
