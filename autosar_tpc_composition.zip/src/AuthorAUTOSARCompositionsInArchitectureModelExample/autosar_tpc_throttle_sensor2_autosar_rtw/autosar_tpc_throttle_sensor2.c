/*
 * File: autosar_tpc_throttle_sensor2.c
 *
 * Code generated for Simulink model 'autosar_tpc_throttle_sensor2'.
 *
 * Model version                  : 1.60
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Thu Aug  3 09:15:09 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "autosar_tpc_throttle_sensor2.h"
#include "autosar_tpc_throttle_sensor2_private.h"
#include "look1_iflf_linlcpw.h"

/* Model step function */
void ThrottleSensor2_Step(void)
{
  Dem_EventStatusType tmp;

  /* Switch: '<S2>/Switch' incorporates:
   *  Constant: '<S2>/Constant'
   *  Constant: '<S2>/Constant1'
   *  Inport: '<Root>/TPS_HwIO_Value'
   *  RelationalOperator: '<Root>/Relational Operator1'
   */
  if (Rte_IRead_ThrottleSensor2_Step_TPS_HwIO_Value() > 1000) {
    tmp = DEM_EVENT_STATUS_PREFAILED;
  } else {
    tmp = DEM_EVENT_STATUS_PASSED;
  }

  /* End of Switch: '<S2>/Switch' */

  /* FunctionCaller: '<Root>/StuckHigh' */
  Rte_Call_S2StuckHigh_SetEventStatus(tmp);

  /* Switch: '<S1>/Switch' incorporates:
   *  Constant: '<S1>/Constant'
   *  Constant: '<S1>/Constant1'
   *  DataStoreRead: '<Root>/Data Store Read'
   *  Inport: '<Root>/TPS_HwIO_Value'
   *  RelationalOperator: '<Root>/Relational Operator'
   */
  if (Rte_IRead_ThrottleSensor2_Step_TPS_HwIO_Value() <
      *Rte_Pim_autosar_tpc_throttl_LowSetPoint()) {
    tmp = DEM_EVENT_STATUS_PREFAILED;
  } else {
    tmp = DEM_EVENT_STATUS_PASSED;
  }

  /* End of Switch: '<S1>/Switch' */

  /* FunctionCaller: '<Root>/StuckLow' */
  Rte_Call_S2StuckLow_SetEventStatus(tmp);

  /* Outport: '<Root>/TPS_Percent_Value' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  Inport: '<Root>/TPS_HwIO_Value'
   *  Lookup_n-D: '<Root>/TPS Lookup'
   */
  Rte_IWrite_ThrottleSensor2_Step_TPS_Percent_Value(look1_iflf_linlcpw
    (Rte_IRead_ThrottleSensor2_Step_TPS_HwIO_Value(),
     (Rte_CData_TPSSecondaryPercent_LkupTbl())->BP1,
     (Rte_CData_TPSSecondaryPercent_LkupTbl())->Table, 10U));
}

/* Model initialize function */
void ThrottleSensor2_Init(void)
{
  /* Start for DataStoreMemory: '<Root>/Data Store Memory' */
  *Rte_Pim_autosar_tpc_throttl_LowSetPoint() = 50U;

  /* Outputs for Atomic SubSystem: '<Root>/Initialize_Function' */
  /* FunctionCaller: '<S3>/NvMServiceCaller' */
  Rte_Call_S2LowSetPoint_ReadBlock(Rte_Pim_autosar_tpc_throttl_LowSetPoint());

  /* End of Outputs for SubSystem: '<Root>/Initialize_Function' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
