/*
 * File: autosar_tpc_throttle_sensor_monitor_private.h
 *
 * Code generated for Simulink model 'autosar_tpc_throttle_sensor_monitor'.
 *
 * Model version                  : 1.50
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Thu Aug  3 09:14:01 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_autosar_tpc_throttle_sensor_monitor_private_h_
#define RTW_HEADER_autosar_tpc_throttle_sensor_monitor_private_h_
#include "rtwtypes.h"
#endif           /* RTW_HEADER_autosar_tpc_throttle_sensor_monitor_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
